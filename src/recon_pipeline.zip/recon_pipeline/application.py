"""Application service coordinating synchronization, policy, and audit logs."""

from __future__ import annotations

import threading
from dataclasses import asdict
from typing import Any, Dict, Optional

from .clock import Timestamp, utc_now_iso
from .models import EEGFeatures, GazeFeatures, PolicyDecision, UIContext
from .policy import MultimodalPolicyEngine
from .storage import JsonlRecorder
from .synchronization import MultimodalSynchronizer


class ExperimentApplication:
    def __init__(
        self,
        synchronizer: MultimodalSynchronizer,
        policy: MultimodalPolicyEngine,
        event_recorder: JsonlRecorder,
        policy_recorder: JsonlRecorder,
    ) -> None:
        self.synchronizer = synchronizer
        self.policy = policy
        self.event_recorder = event_recorder
        self.policy_recorder = policy_recorder
        self._lock = threading.Lock()
        self._latest_policy: Optional[PolicyDecision] = None

    def start_session(self, session_id: str, condition: int = 1) -> dict:
        self.synchronizer.start_session(session_id, condition=condition)
        self.policy.reset()
        with self._lock:
            self._latest_policy = None
        self._record_event("session_started", {"condition": condition}, session_id=session_id)
        return self.snapshot()

    def set_condition(self, condition: int) -> PolicyDecision:
        self.synchronizer.set_condition(condition)
        self.policy.reset()
        self._record_event("condition_changed", {"condition": condition})
        return self.evaluate_policy()

    def update_eeg(self, features: EEGFeatures) -> PolicyDecision:
        self.synchronizer.update_eeg(features)
        self._record_event("eeg_features", features.to_dict())
        return self.evaluate_policy()

    def update_gaze(self, features: GazeFeatures) -> PolicyDecision:
        self.synchronizer.update_gaze(features)
        self._record_event("gaze_features", features.to_dict())
        return self.evaluate_policy()

    def update_ui(self, context: UIContext, trial_id: Optional[str] = None) -> PolicyDecision:
        if trial_id is not None:
            self.synchronizer.set_trial(trial_id, context)
        else:
            self.synchronizer.update_ui(context)
        self._record_event("ui_context", asdict(context))
        return self.evaluate_policy()

    def evaluate_policy(self) -> PolicyDecision:
        state = self.synchronizer.snapshot()
        decision = self.policy.evaluate(state)
        with self._lock:
            self._latest_policy = decision
        self.policy_recorder.append(decision.to_dict())
        return decision

    def latest_policy(self) -> dict:
        with self._lock:
            decision = self._latest_policy
        return decision.to_dict() if decision else self.evaluate_policy().to_dict()

    def snapshot(self) -> dict:
        state = self.synchronizer.snapshot()
        return {
            "ok": True,
            "state": state.to_dict(),
            "policy": self.latest_policy(),
        }

    def recording_context(self) -> dict:
        """Return identifiers needed to attribute an acquisition chunk."""

        state = self.synchronizer.snapshot()
        return {
            "session_id": state.session_id,
            "trial_id": state.trial_id,
            "condition": state.condition,
            "phase": state.ui.phase,
        }

    def _record_event(
        self,
        event_type: str,
        payload: Dict[str, Any],
        *,
        session_id: Optional[str] = None,
    ) -> None:
        state = self.synchronizer.snapshot()
        self.event_recorder.append(
            {
                "schema_version": "1.0",
                "event_type": event_type,
                "session_id": session_id or state.session_id,
                "trial_id": state.trial_id,
                "condition": state.condition,
                "timestamp": Timestamp.now().to_dict(),
                "recorded_at": utc_now_iso(),
                "payload": payload,
            }
        )
