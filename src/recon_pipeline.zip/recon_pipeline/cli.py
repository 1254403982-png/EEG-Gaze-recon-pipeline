"""Command-line entry point for the refactored service."""

from __future__ import annotations

import argparse
import logging
import os
from dataclasses import asdict
from pathlib import Path
from typing import List, Optional

from .acquisition import BrainCoSource
from .application import ExperimentApplication
from .config import load_config
from .eeg import build_eeg_processor
from .gaze import ReplayGazeProvider, TobiiG3Provider
from .policy import MultimodalPolicyEngine
from .runtime import EEGAcquisitionWorker, GazeAcquisitionWorker
from .server import ExperimentHTTPServer
from .server.llm_proxy import LLMProxy
from .storage import JsonDocumentStore, JsonlRecorder, RawEEGRecorder
from .synchronization import MultimodalSynchronizer


def build_application(config_path: Path) -> tuple:
    config = load_config(config_path)
    synchronizer = MultimodalSynchronizer(
        max_eeg_age_ms=config.synchronization.max_eeg_age_ms,
        max_gaze_age_ms=config.synchronization.max_gaze_age_ms,
    )
    application = ExperimentApplication(
        synchronizer=synchronizer,
        policy=MultimodalPolicyEngine(config.policy),
        event_recorder=JsonlRecorder(config.storage.event_log),
        policy_recorder=JsonlRecorder(config.storage.policy_log),
    )
    return config, application


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Realtime BrainCo EEG/gaze policy pipeline")
    parser.add_argument(
        "--config", type=Path, default=Path("configs/development.json"), help="JSON config path"
    )
    parser.add_argument("--brainco", action="store_true", help="Start real BrainCo acquisition")
    parser.add_argument(
        "--legacy-oi-mi",
        type=Path,
        default=Path("../oi-armi/oi-mi"),
        help=argparse.SUPPRESS,
    )
    gaze = parser.add_mutually_exclusive_group()
    gaze.add_argument(
        "--tobii",
        action="store_true",
        help="Start a real Tobii Pro Glasses 3 gaze stream",
    )
    gaze.add_argument(
        "--gaze-replay",
        type=Path,
        default=None,
        help="Replay gaze feature JSONL while real gaze hardware is unavailable",
    )
    parser.add_argument(
        "--gaze-replay-loop",
        action="store_true",
        help="Loop the gaze replay file until the service stops",
    )
    parser.add_argument(
        "--tobii-hostname",
        default=None,
        help="Tobii G3 hostname/serial; defaults to G3_HOSTNAME, then auto-discovery",
    )
    parser.add_argument(
        "--tobii-discovery-timeout",
        type=float,
        default=8.0,
        help="Seconds to wait for Tobii zeroconf discovery",
    )
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = _parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    config, application = build_application(args.config)
    application.start_session("development", condition=1)
    tobii_provider: Optional[TobiiG3Provider] = None
    if args.tobii:
        hostname = args.tobii_hostname or os.environ.get("G3_HOSTNAME")
        tobii_provider = TobiiG3Provider(
            hostname,
            using_zeroconf=hostname is None,
            discovery_timeout_seconds=args.tobii_discovery_timeout,
        )
    server = ExperimentHTTPServer(
        application,
        host=config.server.host,
        port=config.server.port,
        document_store=JsonDocumentStore(config.storage.experiment_data_dir),
        llm_proxy=LLMProxy(config.llm),
        scene_frame_supplier=(
            tobii_provider.latest_scene_frame if tobii_provider is not None else None
        ),
        screen_mapping_supplier=(
            tobii_provider.latest_screen_mapping if tobii_provider is not None else None
        ),
        screen_layout_updater=(
            tobii_provider.update_screen_layout if tobii_provider is not None else None
        ),
    )
    worker: Optional[EEGAcquisitionWorker] = None
    if args.brainco:
        source = BrainCoSource(
            sampling_rate_hz=config.eeg.sampling_rate_hz,
            acquirer_kwargs=asdict(config.eeg.brainco),
        )
        raw_recorder = RawEEGRecorder(
            config.storage.raw_eeg_dir,
            chunk_seconds=config.storage.raw_eeg_chunk_seconds,
        )
        worker = EEGAcquisitionWorker(
            source,
            application,
            processor=build_eeg_processor(config.eeg),
            raw_recorder=raw_recorder,
        )
        worker.start()
    gaze_worker: Optional[GazeAcquisitionWorker] = None
    if tobii_provider is not None:
        gaze_worker = GazeAcquisitionWorker(
            tobii_provider,
            application,
            session_id="development",
            raw_recorder=JsonlRecorder(config.storage.raw_gaze_log),
        )
        gaze_worker.start()
    elif args.gaze_replay is not None:
        gaze_worker = GazeAcquisitionWorker(
            ReplayGazeProvider(args.gaze_replay, loop=args.gaze_replay_loop),
            application,
            session_id="development",
        )
        gaze_worker.start()
    host, port = server.address[:2]
    print("Recon pipeline")
    print("  Home:       http://%s:%s/" % (host, port))
    print("  Experiment: http://%s:%s/experiment" % (host, port))
    print("  Monitor:    http://%s:%s/monitor" % (host, port))
    print("  Health:     http://%s:%s/api/health" % (host, port))
    if worker is not None:
        print("  Raw EEG:    %s" % config.storage.raw_eeg_dir.expanduser().resolve())
    if gaze_worker is not None:
        print(
            "  Gaze:       %s"
            % ("Tobii G3 realtime" if args.tobii else "JSONL replay")
        )
        if args.tobii:
            print("  Raw gaze:   %s" % config.storage.raw_gaze_log.expanduser().resolve())
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    finally:
        if worker is not None:
            worker.stop()
        if gaze_worker is not None:
            gaze_worker.stop()
        server.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
