"""Built-in EEG decoders and registry helpers."""

from .posterior_alpha import PosteriorAlphaDecoder
from .registry import build_decoder, register_decoder

__all__ = ["PosteriorAlphaDecoder", "build_decoder", "register_decoder"]
