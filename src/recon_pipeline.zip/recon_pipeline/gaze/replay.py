"""Deterministic JSONL gaze replay for integration tests and UI development."""

from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from ..clock import Timestamp
from ..models import GazeFeatures, SignalStatus


class ReplayGazeProvider:
    def __init__(self, source: Path, *, loop: bool = False) -> None:
        self.source = source.expanduser().resolve()
        self.loop = loop
        self._records: List[dict] = []
        self._index = 0
        self._running = False

    @property
    def is_running(self) -> bool:
        return self._running

    def start(self, session_id: str) -> None:
        del session_id
        records: List[dict] = []
        with self.source.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                value = json.loads(line)
                if not isinstance(value, dict):
                    raise ValueError("Gaze replay line %s must be a JSON object." % line_number)
                records.append(value)
        if not records:
            raise ValueError("Gaze replay file contains no records.")
        self._records, self._index, self._running = records, 0, True

    def read(self) -> Optional[GazeFeatures]:
        if not self._running:
            raise RuntimeError("Gaze replay is not started.")
        if self._index >= len(self._records):
            if not self.loop:
                return None
            self._index = 0
        item = self._records[self._index]
        self._index += 1
        return GazeFeatures(
            timestamp=Timestamp.now(device_seconds=_optional_float(item.get("device_timestamp"))),
            status=SignalStatus(str(item.get("status", "available"))),
            quality=str(item.get("quality", "pass")),
            x_normalized=_optional_float(item.get("x_normalized")),
            y_normalized=_optional_float(item.get("y_normalized")),
            primary_aoi=_optional_str(item.get("primary_aoi")),
            fixation_duration_ms=_optional_float(item.get("fixation_duration_ms")),
            fixation_rate=_optional_float(item.get("fixation_rate")),
            saccade_rate=_optional_float(item.get("saccade_rate")),
            pupil_dilation=_optional_float(item.get("pupil_dilation")),
            gaze_entropy=_optional_float(item.get("gaze_entropy")),
            blink_rate=_optional_float(item.get("blink_rate")),
            valid_sample_ratio=_optional_float(item.get("valid_sample_ratio")),
            source="replay",
            metadata={"replay_index": self._index - 1},
        )

    def stop(self) -> None:
        self._running = False
        self._records = []
        self._index = 0


def _optional_float(value: object) -> Optional[float]:
    return None if value is None else float(value)


def _optional_str(value: object) -> Optional[str]:
    return None if value is None else str(value)
