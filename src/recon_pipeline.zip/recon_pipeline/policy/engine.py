"""Auditable EEG/gaze policy rules with source isolation and stabilization."""

from __future__ import annotations

import threading
import time
from typing import List, Optional, Tuple

import numpy as np

from ..clock import Timestamp
from ..config import PolicyConfig
from ..models import GazeFeatures, MultimodalState, PolicyDecision, SignalStatus

_SEVERITY = {"none": 0, "brief": 1, "example": 2, "detailed": 3}


class MultimodalPolicyEngine:
    """Generate a platform action without silently crossing condition boundaries."""

    def __init__(self, config: PolicyConfig) -> None:
        self.config = config
        self._lock = threading.Lock()
        self._next_policy_id = 1
        self._candidate_level = "none"
        self._candidate_count = 0
        self._last_emitted_level = "none"
        self._last_emitted_at = 0.0

    def reset(self) -> None:
        with self._lock:
            self._candidate_level = "none"
            self._candidate_count = 0
            self._last_emitted_level = "none"
            self._last_emitted_at = 0.0

    def evaluate(self, state: MultimodalState) -> PolicyDecision:
        with self._lock:
            decision = self._evaluate_unlocked(state)
            decision.policy_id = self._next_policy_id
            self._next_policy_id += 1
            return decision

    def _evaluate_unlocked(self, state: MultimodalState) -> PolicyDecision:
        eeg_valid = state.eeg.status == SignalStatus.AVAILABLE and state.eeg.quality == "pass"
        gaze_valid = state.gaze.status == SignalStatus.AVAILABLE and state.gaze.quality == "pass"
        available = []
        if eeg_valid:
            available.append("eeg")
        if gaze_valid:
            available.append("gaze")

        disabled_phases = {
            "quiz",
            "rest",
            "calibration",
            "condition_feedback",
            "final_feedback",
            "questionnaire",
        }
        if state.ui.phase.strip().lower() in disabled_phases:
            self._candidate_level = "none"
            self._candidate_count = 0
            return self._decision(
                state,
                level="none",
                action="no_adaptation",
                ui_mode="normal",
                reasons=["ui_phase_policy_disabled"],
                available=available,
                used=[],
                suppressed=True,
            )

        if state.condition == 1:
            return self._decision(
                state,
                level="none",
                action="no_adaptation",
                ui_mode="normal",
                reasons=["condition_c1_policy_disabled"],
                available=available,
                used=[],
            )

        score: Optional[float] = None
        used: List[str] = []
        reasons: List[str] = []
        degraded: Optional[str] = None
        confidence = 0.0

        if state.condition == 2:
            if not gaze_valid:
                return self._insufficient(state, available, "required_gaze_unavailable")
            score, gaze_reasons = _gaze_difficulty_score(state.gaze, self.config)
            if score is None:
                return self._insufficient(state, available, "gaze_features_incomplete")
            used, reasons, confidence = ["gaze"], gaze_reasons, 0.75

        elif state.condition == 3:
            if eeg_valid and gaze_valid:
                gaze_score, gaze_reasons = _gaze_difficulty_score(state.gaze, self.config)
                if gaze_score is None:
                    if not self.config.allow_degraded_c3:
                        return self._insufficient(state, available, "gaze_features_incomplete")
                    score = _eeg_score(state)
                    used, reasons = ["eeg"], ["gaze_features_incomplete"]
                    degraded, confidence = "eeg_only", 0.55
                else:
                    eeg_score = _eeg_score(state)
                    weight_total = self.config.eeg_weight + self.config.gaze_weight
                    score = (
                        self.config.eeg_weight * eeg_score
                        + self.config.gaze_weight * gaze_score
                    ) / weight_total
                    used = ["eeg", "gaze"]
                    reasons = _eeg_reasons(eeg_score, self.config) + gaze_reasons
                    confidence = 0.85
            elif eeg_valid and self.config.allow_degraded_c3:
                score = _eeg_score(state)
                used, reasons = ["eeg"], ["gaze_unavailable"]
                degraded, confidence = "eeg_only", 0.55
            else:
                missing = (
                    "required_eeg_unavailable" if not eeg_valid else "required_gaze_unavailable"
                )
                return self._insufficient(state, available, missing)

        assert score is not None
        level = _level_for_score(score, self.config)
        reasons.extend(_eeg_reasons(score, self.config) if used == ["eeg"] else [])
        target_aoi = state.gaze.primary_aoi if gaze_valid else None
        return self._stabilize(
            state,
            level=level,
            score=score,
            reasons=_unique(reasons),
            available=available,
            used=used,
            confidence=confidence,
            degraded=degraded,
            target_aoi=target_aoi,
        )

    def _stabilize(
        self,
        state: MultimodalState,
        *,
        level: str,
        score: float,
        reasons: List[str],
        available: List[str],
        used: List[str],
        confidence: float,
        degraded: Optional[str],
        target_aoi: Optional[str],
    ) -> PolicyDecision:
        if level == self._candidate_level:
            self._candidate_count += 1
        else:
            self._candidate_level, self._candidate_count = level, 1

        if level != "none" and self._candidate_count < self.config.required_confirmations:
            return self._decision(
                state,
                level="none",
                action="hold",
                ui_mode="normal",
                reasons=[*reasons, "awaiting_confirmation"],
                available=available,
                used=used,
                confidence=confidence,
                degraded=degraded,
                target_aoi=target_aoi,
                difficulty_score=score,
                suppressed=True,
            )

        now = time.monotonic()
        is_escalation = _SEVERITY[level] > _SEVERITY[self._last_emitted_level]
        cooling_down = now - self._last_emitted_at < self.config.cooldown_seconds
        if is_escalation and cooling_down:
            return self._decision(
                state,
                level=self._last_emitted_level,
                action="hold",
                ui_mode=_ui_mode(self._last_emitted_level),
                reasons=[*reasons, "policy_cooldown"],
                available=available,
                used=used,
                confidence=confidence,
                degraded=degraded,
                target_aoi=target_aoi,
                difficulty_score=score,
                suppressed=True,
            )

        if level != self._last_emitted_level:
            self._last_emitted_level = level
            self._last_emitted_at = now
        reasons.append("difficulty_score_%.1f" % score)
        return self._decision(
            state,
            level=level,
            action=_action(level),
            ui_mode=_ui_mode(level),
            reasons=reasons,
            available=available,
            used=used,
            confidence=confidence,
            degraded=degraded,
            target_aoi=target_aoi,
            difficulty_score=score,
        )

    def _insufficient(
        self, state: MultimodalState, available: List[str], reason: str
    ) -> PolicyDecision:
        return self._decision(
            state,
            level="none",
            action="hold",
            ui_mode="normal",
            reasons=[reason],
            available=available,
            used=[],
            confidence=0.0,
            degraded="insufficient_input",
            suppressed=True,
        )

    @staticmethod
    def _decision(
        state: MultimodalState,
        *,
        level: str,
        action: str,
        ui_mode: str,
        reasons: List[str],
        available: List[str],
        used: List[str],
        confidence: float = 0.0,
        degraded: Optional[str] = None,
        target_aoi: Optional[str] = None,
        difficulty_score: Optional[float] = None,
        suppressed: bool = False,
    ) -> PolicyDecision:
        return PolicyDecision(
            policy_id=0,
            session_id=state.session_id,
            trial_id=state.trial_id,
            condition=state.condition,
            timestamp=Timestamp.now(),
            action=action,
            explanation_level=level,
            ui_mode=ui_mode,
            reason_codes=_unique(reasons),
            sources_available=available,
            sources_used=used,
            target_aoi=target_aoi,
            difficulty_score=difficulty_score,
            confidence=confidence,
            degraded_mode=degraded,
            suppressed=suppressed,
        )


def _eeg_score(state: MultimodalState) -> float:
    value = state.eeg.cognitive_load
    return float(np.clip(50.0 if value is None else value, 0.0, 100.0))


def _eeg_reasons(score: float, config: PolicyConfig) -> List[str]:
    if score >= config.detailed_threshold:
        return ["eeg_very_high_load"]
    if score >= config.example_threshold:
        return ["eeg_high_load"]
    if score >= config.brief_threshold:
        return ["eeg_moderate_load"]
    return ["eeg_low_load"]


def _gaze_difficulty_score(
    gaze: GazeFeatures, config: PolicyConfig
) -> Tuple[Optional[float], List[str]]:
    components: List[Tuple[float, float, str]] = []
    if gaze.pupil_dilation is not None:
        components.append(
            (_unit(gaze.pupil_dilation), config.gaze_pupil_weight, "gaze_pupil_dilation")
        )
    if gaze.gaze_entropy is not None:
        components.append(
            (_unit(gaze.gaze_entropy), config.gaze_entropy_weight, "gaze_high_entropy")
        )
    if gaze.fixation_duration_ms is not None:
        components.append(
            (
                float(
                    np.clip(gaze.fixation_duration_ms / config.fixation_reference_ms, 0.0, 1.0)
                ),
                config.gaze_fixation_weight,
                "gaze_long_fixation",
            )
        )
    if gaze.blink_rate is not None:
        components.append((_unit(gaze.blink_rate), config.gaze_blink_weight, "gaze_blink_rate"))
    components = [component for component in components if component[1] > 0]
    if not components:
        return None, []
    total_weight = sum(weight for _, weight, _ in components)
    score = 100.0 * sum(value * weight for value, weight, _ in components) / total_weight
    reasons = [reason for value, _, reason in components if value >= 0.6]
    return float(score), reasons or ["gaze_nominal"]


def _unit(value: float) -> float:
    return float(np.clip(value, 0.0, 1.0))


def _level_for_score(score: float, config: PolicyConfig) -> str:
    if score > config.detailed_threshold:
        return "detailed"
    if score >= config.example_threshold:
        return "example"
    if score >= config.brief_threshold:
        return "brief"
    return "none"


def _action(level: str) -> str:
    return {
        "none": "continue",
        "brief": "offer_brief_explanation",
        "example": "offer_example",
        "detailed": "offer_detailed_explanation",
    }[level]


def _ui_mode(level: str) -> str:
    return "normal" if level == "none" else "assistance"


def _unique(values: List[str]) -> List[str]:
    return list(dict.fromkeys(values))
