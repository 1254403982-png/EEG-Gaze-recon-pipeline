window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:33, title:"概率论与统计推断基础", domain:"数学", difficulty:"高", diffClass:"is-high",
    summary:"概率描述不确定性，贝叶斯公式逆向更新信念，正态分布与大数定律是统计推断的两大支柱。",
    quickQs:["贝叶斯公式的直觉","大数定律与中心极限定理","给我出道练习题","用通俗语言解释"],
    content:`<p>"明天下雨概率30%"到底是什么意思？是100天里有30天下雨，还是科学家的主观置信度？<strong>概率论</strong>就是用数学刻画不确定性的语言，而<strong>统计推断</strong>是用数据反推未知规律的工具。</p>
<h3>条件概率与贝叶斯公式</h3>
<p>条件概率 P(A|B) 表示"在B发生的前提下A发生的概率"。比如"带伞的人里有多少真的遇到雨"。贝叶斯公式则是<strong>逆向推理</strong>的利器：</p>
<div class="formula-block"><span class="formula-label">贝叶斯公式</span>P(A|B) = P(B|A)·P(A) / P(B)<br>后验 = 似然 × 先验 / 证据</div>
<p>直觉：你先有一个<strong>先验信念</strong>P(A)（比如"这种病发病率1%"），看到新证据B（比如"检测阳性"）后，用似然P(B|A)更新成<strong>后验</strong>P(A|B)。这就是为什么医学筛查阳性后还要进一步检查——如果基础发病率很低，即使检测很准，绝大多数阳性也可能是假阳性。</p>
<h3>大数定律：频率趋近概率</h3>
<p>抛硬币次数足够多，正面比例会趋近1/2。这就是<strong>大数定律</strong>：样本均值随样本量增大趋近于真实期望值。它是"用频率估计概率"的理论基础。</p>
<h3>正态分布与中心极限定理</h3>
<p>身高、误差、考试成绩……大量自然与社会现象近似服从钟形曲线（<strong>正态分布</strong>）。更神奇的是<strong>中心极限定理</strong>：无论原始数据什么分布，只要样本量足够大，样本均值的分布都趋近正态。这就是为什么正态分布在统计分析中无处不在——它让复杂问题变得可计算。</p>`,
    quiz:[{ question:"贝叶斯公式的核心作用是？", options:["A. 正向计算联合概率","B. 用新证据逆向更新信念(先验→后验)","C. 计算无条件概率","D. 证明两个事件独立"], answerIndex:1 },
           { question:"中心极限定理告诉我们什么？", options:["A. 所有随机变量都服从正态分布","B. 大样本下样本均值的分布趋近正态","C. 样本量越大方差越大","D. 概率永远等于频率"], answerIndex:1 }] }
);
