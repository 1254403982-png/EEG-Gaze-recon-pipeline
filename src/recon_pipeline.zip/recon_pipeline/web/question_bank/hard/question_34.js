window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:34, title:"狭义相对论与时空观", domain:"物理", difficulty:"高", diffClass:"is-high",
    summary:"狭义相对论揭示时间和空间不是绝对的，运动参考系中时间会变慢、长度会收缩，质能等价E=mc²统一了质量和能量。",
    quickQs:["钟慢效应与尺缩效应","E=mc²的含义","给我出道练习题","用通俗语言解释"],
    content:`<p>1905年，26岁的爱因斯坦提出了<strong>狭义相对论</strong>，彻底颠覆了牛顿以来"时间绝对、空间绝对"的常识。它的出发点只有两条看似简单的假设，却推演出一连串反直觉的结论。</p>
<h3>两条基本假设</h3>
<ul style="padding-left:20px;">
<li><strong>相对性原理</strong>：所有惯性参考系中物理定律相同（没有"绝对静止"的参考系）。</li>
<li><strong>光速不变原理</strong>：真空中光速c对任何观察者都相同，与光源或观察者的运动无关。</li>
</ul>
<p>第二条最反直觉：无论你以多快速度追着光跑，测得的光速永远是c，不会变慢。为了维护这个不变性，时间和空间必须"让步"——于是诞生了钟慢和尺缩。</p>
<h3>钟慢效应（时间膨胀）</h3>
<div class="formula-block"><span class="formula-label">时间膨胀公式</span>Δt = Δt₀ / √(1 - v²/c²)<br>Δt₀ = 静止参考系的时间（原时）<br>Δt = 运动参考系观测到的时间</div>
<p>运动越快，时间流逝越慢。一架以接近光速飞行的飞船上过了一天，地球上可能已过了数年。这不是错觉，而是时空的真实几何属性（GPS卫星就要修正这种相对论时间差，否则定位会漂移）。</p>
<h3>质能等价 E=mc²</h3>
<p>狭义相对论最著名的结论是<strong>质量和能量等价</strong>：</p>
<div class="formula-block"><span class="formula-label">质能方程</span>E = mc²<br>质量本身就是高度浓缩的能量</div>
<p>这意味着：物体的能量不仅来自运动，还来自它"静止时"的质量本身。核反应（裂变/聚变）中极小质量亏损Δm就能释放巨大能量 ΔE = Δm·c²——这正是原子弹和太阳发光的根源。</p>`,
    quiz:[{ question:"根据狭义相对论，一个相对于你高速运动的时钟，你观测到它的走时会怎样？", options:["A. 和你的钟一样快","B. 比你的钟慢（时间膨胀）","C. 比你的钟快","D. 完全停止"], answerIndex:1 },
           { question:"质能方程 E=mc² 的核心含义是？", options:["A. 能量总是等于质量","B. 质量和能量本质上是等价的，可相互转化","C. 光速是质量的度量","D. 运动速度越快质量越小"], answerIndex:1 }] }
);
