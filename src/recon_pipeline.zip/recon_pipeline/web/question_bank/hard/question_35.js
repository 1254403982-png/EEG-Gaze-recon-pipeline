window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:35, title:"化学平衡与勒夏特列原理", domain:"化学", difficulty:"高", diffClass:"is-high",
    summary:"可逆反应达到动态平衡时正逆速率相等，勒夏特列原理预测平衡如何随浓度、温度、压强变化而移动。",
    quickQs:["什么是动态平衡","勒夏特列原理的应用","给我出道练习题","用通俗语言解释"],
    content:`<p>合成氨工厂里，氢气和氮气反应生产氨——但反应永远进行不完全，总有一部分原料剩下。为什么不能一次反应到底？这涉及到化学中最核心的概念之一：<strong>化学平衡</strong>。</p>
<h3>动态平衡：正逆反应速率相等</h3>
<p>很多反应是可逆的：反应物生成产物的同时，产物也在变回反应物。用双箭头表示：N₂ + 3H₂ ⇌ 2NH₃。一开始正反应速率大、逆反应慢；随着产物积累，逆反应加快、正反应因原料减少而减慢。最终<strong>正逆速率相等</strong>，各物质浓度不再变化——这就是<strong>化学平衡</strong>。注意：此时反应并没停止，而是正逆在进行、宏观上"看起来没变化"，所以叫<strong>动态平衡</strong>。</p>
<h3>平衡常数 K</h3>
<div class="formula-block"><span class="formula-label">平衡常数表达式</span>对 aA + bB ⇌ cC + dD<br>K = [C]^c [D]^d / ([A]^a [B]^b)<br>K 越大，说明平衡时产物占比越高</div>
<p>K只与温度有关，与初始浓度无关。给定温度，无论你从哪边开始（纯反应物或纯产物），最终都会到达同一个平衡点。</p>
<h3>勒夏特列原理：平衡会"对抗"扰动</h3>
<p>如果改变平衡系统的条件，平衡会向着<strong>削弱这种改变</strong>的方向移动。这就像系统有"惰性"，不让外界轻易打破它的稳态：</p>
<table class="data-table">
<tr><th>扰动</th><th>平衡移动方向</th><th>实例</th></tr>
<tr><td>增大反应物浓度</td><td>正向移动（消耗新增反应物）</td><td>多加N₂→多产NH₃</td></tr>
<tr><td>升高温度</td><td>向吸热方向移动</td><td>合成氨放热→升温反而不利</td></tr>
<tr><td>增大压强</td><td>向气体分子数少的方向</td><td>N₂+3H₂→2NH₃，加压有利</td></tr>
</table>
<p>工业合成氨正是利用这些原理：适当加压、控制温度、不断移走产物来"推"平衡向右，提高产率。</p>`,
    quiz:[{ question:"化学平衡状态下，正反应和逆反应的关系是？", options:["A. 正反应完全停止","B. 正逆反应速率相等（动态平衡）","C. 逆反应完全停止","D. 反应物全部耗尽"], answerIndex:1 },
           { question:"对放热反应，升高温度会使平衡如何移动？", options:["A. 向正反应方向（产更多产物）","B. 向逆反应方向（吸热方向）","C. 不移动","D. 反应完全停止"], answerIndex:1 }] }
);
