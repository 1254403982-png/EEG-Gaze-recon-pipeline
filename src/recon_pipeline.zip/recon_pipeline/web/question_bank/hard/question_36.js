window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:36, title:"蛋白质折叠与分子伴侣", domain:"生物", difficulty:"高", diffClass:"is-high",
    summary:"Anfinsen定理证明天然蛋白质结构由氨基酸序列决定，Levinthal悖论表明折叠通过能量漏斗实现而非随机搜索。",
    quickQs:["Levinthal悖论的含义","能量漏斗模型","给我出道练习题","用通俗语言解释"],
    content:`<p>一条线性的多肽链如何在细胞内精准折叠成有功能的3D结构？这个答案不仅关乎生命本质，也是阿尔茨海默症等疾病的根源。</p>
<h3>Anfinsen定理（1961）</h3>
<p>生物化学家Anfinsen用核糖核酸酶A做实验：用化学试剂把蛋白质"变性"（拆开结构），再移除试剂让它"复性"。结果：尽管二硫键有105种可能的配对方式，复性产物几乎全部恢复成天然构象。</p>
<div class="formula-block"><span class="formula-label">Anfinsen定理</span>蛋白质的天然三维结构完全由氨基酸序列决定，<br>是生理条件下<strong>吉布斯自由能最低</strong>的状态（ΔG &lt; 0）</div>
<p>换言之：折叠的全部"指令"都编码在那一串氨基酸序列里，不需要额外的模板。</p>
<h3>Levinthal悖论（1969）</h3>
<p>如果蛋白质随机尝试每一种可能的构象来寻找最低能量结构，需要多久？</p>
<div class="formula-block"><span class="formula-label">Levinthal估算</span>100个残基：3¹⁰⁰ ≈ 10⁴⁸ 种构象<br>每皮秒试一种 → 需 10³⁶ 秒 ≈ 10²⁸ 年<br>实际折叠：毫秒到秒级</div>
<p>实际比随机搜索快了天文数字倍——说明折叠<strong>不是瞎找</strong>，而是有导向的。</p>
<h3>能量漏斗模型</h3>
<p>折叠过程像一个小球沿着"能量山坡"滚向谷底：去折叠态（高能量、构象空间巨大）→ 疏水塌缩 → 过渡态 → 天然态（最低能量、单一构象）。<strong>分子伴侣</strong>（如GroEL/ES）像"折叠助手"，为多肽提供隔离空间，防止错误聚集。AlphaFold（2020）从序列预测结构，精度已接近实验水平。</p>`,
    quiz:[{ question:"根据Anfinsen定理，蛋白质的天然结构由什么决定？", options:["A. 细胞内的温度","B. 氨基酸序列本身（最低自由能态）","C. 分子伴侣的种类","D. 细胞器的位置"], answerIndex:1 },
           { question:"Levinthal悖论的核心结论是？", options:["A. 蛋白质无法折叠","B. 随机搜索所有构象耗时远超实际折叠时间，故折叠必有导向机制","C. Anfinsen定理错误","D. 蛋白质没有确定结构"], answerIndex:1 }] }
);
