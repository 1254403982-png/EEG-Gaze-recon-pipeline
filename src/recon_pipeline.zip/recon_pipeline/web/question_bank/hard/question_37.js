window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:37, title:"机器学习入门：从数据到模型", domain:"计算机", difficulty:"高", diffClass:"is-high",
    summary:"机器学习让计算机从数据中自动归纳规律，监督学习通过标注样本训练模型实现预测，过拟合是核心挑战。",
    quickQs:["监督学习与无监督学习的区别","什么是过拟合","给我出道练习题","用通俗语言解释"],
    content:`<p>你打开购物App，它推荐的东西越来越合你心意；你上传照片，手机自动识别出人脸——这些背后都是<strong>机器学习</strong>。它和传统编程最大的不同是：不是人写死规则，而是让计算机<strong>从数据中自己学出规则</strong>。</p>
<h3>核心范式：监督学习</h3>
<p>想象教小孩认猫：你拿一堆图片，每张都告诉他"这是猫""这不是猫"。小孩看多了，以后见到新图片就能判断。机器学习的<strong>监督学习</strong>一模一样：</p>
<div class="formula-block"><span class="formula-label">监督学习流程</span>
训练数据 = (输入x, 正确标签y) 成对提供<br>
模型 f(x) 不断调整参数，使预测 f(x) ≈ y<br>
训练好后，对全新的 x 给出预测</div>
<p>比如垃圾邮件分类：用大量"已标注垃圾/非垃圾"的邮件训练，模型学会区分特征（某些关键词、发件频率等），之后自动过滤新邮件。</p>
<h3>无监督学习</h3>
<p>如果数据没有标签呢？<strong>无监督学习</strong>让算法自己发现结构。典型任务如聚类：把客户按消费行为自动分成几类，用于精准营销。没人告诉算法"这几类叫什么"，它只是找出"哪些人相似"。</p>
<h3>最大的坑：过拟合</h3>
<p>模型可能会"死记硬背"训练数据（包括其中的噪音），导致在训练集上表现完美，但遇到新数据就失灵。这叫<strong>过拟合</strong>。</p>
<div class="formula-block"><span class="formula-label">过拟合类比</span>像学生背下习题答案但没理解原理<br>考试遇到变形题就错</div>
<p>解决方法：留出"验证集"测试泛化能力、增加数据量、正则化（限制模型复杂度）。目标永远是——模型要在<strong>没见过的数据</strong>上也好用。</p>`,
    quiz:[{ question:"监督学习区别于无监督学习的关键特征是？", options:["A. 使用了更多计算机","B. 训练数据带有正确标签(输入-输出对)","C. 不需要训练","D. 只能处理图像"], answerIndex:1 },
           { question:"模型在训练集上准确率100%但测试集很差，这种现象叫？", options:["A. 欠拟合","B. 过拟合","C. 收敛","D. 梯度下降"], answerIndex:1 }] }
);
