window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:38, title:"动态规划与最优决策", domain:"经济学", difficulty:"高", diffClass:"is-high",
    summary:"贝尔曼方程将多期最优决策分解为递归的单期选择，值函数迭代和策略迭代是求解马尔可夫决策过程的标准方法。",
    quickQs:["贝尔曼方程的直觉","值函数迭代与策略迭代","给我出道练习题","用通俗语言解释"],
    content:`<p>假设你规划未来20年的职业：每年可以选择深造、跳槽或创业，每种选择影响收入和未来机会。怎样选一条总体最优的路？<strong>动态规划</strong>就是求解这类"多阶段决策"问题的数学框架，从个人理财到机器人路径规划都用它。</p>
<h3>贝尔曼最优性原理</h3>
<p>核心洞察极其优雅：<strong>无论你过去怎么走到今天，从今天往后的剩余决策，必须是对当前状态而言的最优策略</strong>。这把"想20年"的难题，拆成了"每年做一个局部最优选择，且这个选择考虑了未来的回报"的递归问题。</p>
<div class="formula-block"><span class="formula-label">贝尔曼方程</span>$$V^*(s) = \\max_a \\left[ r(s,a) + \\gamma \\cdot \\sum_{s'} P(s'\\mid s,a) \\cdot V^*(s') \\right]$$<br>$V^*$ = 最优值函数（最优总回报）<br>r = 即时奖励，γ = 折扣因子(0~1)<br>P = 转移概率，$s'$ = 下一状态</div>
<p>含义：在状态 s 下的最优价值 = 当前能拿到的奖励 + 折扣后的未来最优价值。右侧又出现了 $V^*$ 本身，这种"自我引用"通过迭代求解。</p>
<h3>两种求解算法</h3>
<table class="data-table">
<tr><th>方法</th><th>思路</th><th>特点</th></tr>
<tr><td>值函数迭代</td><td>反复套用贝尔曼方程更新V，直到收敛</td><td>简单，γ越接近1越慢</td></tr>
<tr><td>策略迭代</td><td>交替"评估当前策略"和"改进策略"</td><td>通常收敛更快</td></tr>
</table>
<h3>连续时间推广：LQR</h3>
<p>当状态连续（如机器人关节角度），问题变成<strong>最优控制</strong>。线性二次型调节器(LQR)给出优美闭式解：最优控制 = 状态反馈 u = -Kx，其中K由代数Riccati方程解出。LQR广泛用于飞行器姿态控制、工业机器人轨迹跟踪。</p>
<h3>从理论到现实：维数灾难与深度强化学习</h3>
<p>贝尔曼方程看似简单，但当状态空间巨大（如围棋、连续关节组合）时，连值函数表都存不下——这就是<strong>维数灾难</strong>。现代做法放弃表格、改用神经网络去"逼近"值函数（函数逼近），这正是 AlphaGo 与 RLHF 背后的<strong>深度强化学习</strong>。折扣因子 γ 也不只为数学收敛：它同时刻画了"未来的不确定性"和"宁可先拿奖励"的偏好。</p>`,
    quiz:[{ question:"贝尔曼最优性原理的核心思想是？", options:["A. 只看眼前利益最大化","B. 从当前状态出发的剩余决策必须是最优的","C. 随机搜索策略","D. 历史决定一切"], answerIndex:1 },
           { question:"动态规划将多期最优化问题分解所依赖的核心原理是？", options:["A. 大数定律","B. 贝尔曼最优性原理","C. 纳什均衡","D. 中心极限定理"], answerIndex:1 }] }
);
