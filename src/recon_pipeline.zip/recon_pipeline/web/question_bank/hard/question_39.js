window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:39, title:"记忆系统与遗忘曲线", domain:"心理学", difficulty:"高", diffClass:"is-high",
    summary:"记忆分为感觉、短时、长时三个阶段，艾宾浩斯遗忘曲线揭示遗忘先快后慢，间隔重复是抵御遗忘的有效策略。",
    quickQs:["记忆的三个阶段","艾宾浩斯遗忘曲线","给我出道练习题","用通俗语言解释"],
    content:`<p>为什么刚背的单词第二天就忘了一大半？为什么考试前突击的效果不持久？心理学家对记忆的研究，给出了科学的答案和应对方法。</p>
<h3>记忆的三个仓库</h3>
<p>现代记忆模型把记忆看作一个三阶段的信息加工流水线：</p>
<table class="data-table">
<tr><th>阶段</th><th>容量/时长</th><th>举例</th></tr>
<tr><td>感觉记忆</td><td>极短暂(毫秒~秒)，容量大</td><td>看一眼后视网膜上的余像</td></tr>
<tr><td>短时记忆<br>(工作记忆)</td><td>约7±2个组块，保持约20秒</td><td>临时记一个刚拨的电话号码</td></tr>
<tr><td>长时记忆</td><td>容量几乎无限，可保持终身</td><td>自己的名字、母语</td></tr>
</table>
<p>信息必须经过<strong>编码</strong>（加工理解）和<strong>复述</strong>（反复提取）才能从短时转入长时。死记硬背只停留浅层，容易流失。</p>
<h3>艾宾浩斯遗忘曲线（1885）</h3>
<p>德国心理学家艾宾浩斯以自己为实验对象，背诵无意义音节后测量不同时间间隔的保持率，发现了一条规律：</p>
<div class="formula-block"><span class="formula-label">遗忘曲线特征</span>遗忘进程<strong>先快后慢</strong>：<br>学习后1小时约遗忘50%<br>1天后约遗忘66%<br>之后趋于平缓，稳定在一定水平</div>
<p>这意味着：刚学完的黄金复习窗口极其重要。与其考前突击，不如在遗忘高峰前（如当天、隔天、一周后）复习，事半功倍。</p>
<h3>间隔重复：对抗遗忘的武器</h3>
<p>基于遗忘曲线，<strong>间隔重复（Spaced Repetition）</strong>策略主张：每次复习的间隔逐渐拉长（第1天、第3天、第7天、第15天……）。每次成功提取记忆，都会强化它、推迟下次遗忘。这正是Anki等记忆卡片App的核心算法——也是高效学习的科学秘籍。</p>`,
    quiz:[{ question:"根据艾宾浩斯遗忘曲线，遗忘的进程特点是？", options:["A. 匀速遗忘","B. 先快后慢","C. 先慢后快","D. 完全随机"], answerIndex:1 },
           { question:"要把短时记忆转化为长时记忆，最关键的过程是？", options:["A. 感觉登记","B. 编码与复述（深加工）","C. 加大字体","D. 延长感觉记忆"], answerIndex:1 }] }
);
