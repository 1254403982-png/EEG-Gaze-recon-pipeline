window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:41, title:"肿瘤免疫编辑与检查点治疗", domain:"医学", difficulty:"高", diffClass:"is-high",
    summary:"免疫系统与肿瘤长期博弈，检查点抑制剂解除T细胞的抑制信号来抗癌，但可能引发免疫相关不良反应。",
    quickQs:["免疫编辑的三个阶段","PD-1与CTLA-4的区别","给我出道练习题","用通俗语言解释"],
    content:`<p>为什么我们的免疫系统不能像消灭感冒病毒一样消灭肿瘤？2018年诺贝尔生理学或医学奖授予了肿瘤免疫治疗的开创者，他们的发现揭示：肿瘤很"聪明"，会伪装和压制免疫系统的攻击。</p>
<h3>免疫编辑：免疫系统与肿瘤的博弈</h3>
<p>免疫系统和肿瘤的关系是一个动态的三阶段过程：</p>
<table class="data-table">
<tr><th>阶段</th><th>名称</th><th>免疫-肿瘤关系</th><th>结果</th></tr>
<tr><td>1</td><td>清除(Elimination)</td><td>免疫系统识别并清除早期肿瘤</td><td>肿瘤不形成</td></tr>
<tr><td>2</td><td>平衡(Equilibrium)</td><td>免疫控制但不能根除，肿瘤在压力下进化</td><td>长期带瘤</td></tr>
<tr><td>3</td><td>逃逸(Escape)</td><td>肿瘤获得逃逸机制</td><td>临床可见生长</td></tr>
</table>
<p>核心洞察：免疫攻击本身是<strong>选择压力</strong>——它杀死了高免疫原性的癌细胞，筛选出低免疫原性、能逃避免疫的变体（如下调MHC分子、高表达PD-L1）。</p>
<h3>免疫检查点：免疫系统的"刹车"</h3>
<p>T细胞杀敌时需要被精准调控，否则会误伤正常组织。进化出"检查点"分子作为<strong>刹车</strong>：完成任务后，CTLA-4、PD-1等分子上调，抑制T细胞活性。但肿瘤狡猾地利用这个刹车来自保：</p>
<div class="formula-block"><span class="formula-label">两个关键检查点</span>
<strong>CTLA-4</strong>：在淋巴结内，T细胞启动阶段踩刹车<br>
<strong>PD-1/PD-L1</strong>：在肿瘤微环境中，效应阶段踩刹车（肿瘤细胞高表达PD-L1）</div>
<h3>检查点抑制剂：松开刹车</h3>
<p><strong>免疫检查点抑制剂（ICI）</strong>是解除这些刹车的抗体药物。CTLA-4抑制剂（伊匹木单抗）和PD-1/PD-L1抑制剂（如帕博利珠单抗）已将晚期黑色素瘤5年生存率从不足15%提升到40%以上。但代价是：松开刹车可能让免疫系统攻击自身正常组织，引发<strong>免疫相关不良反应(irAEs)</strong>，如免疫性肺炎、肝炎、心肌炎等，需密切监测。</p>`,
    quiz:[{ question:"PD-1/PD-L1检查点抑制剂主要在哪一步起作用？", options:["A. 淋巴结内T细胞启动期","B. 外周组织/肿瘤微环境效应期","C. 胸腺发育期","D. 骨髓造血期"], answerIndex:1 },
           { question:"免疫检查点抑制剂（如抗PD-1抗体）发挥抗癌作用的机制是？", options:["A. 直接毒杀肿瘤细胞","B. 解除T细胞的抑制信号，恢复其杀伤功能","C. 替代化疗药物","D. 增强肿瘤细胞MHC表达"], answerIndex:1 }] }
);
