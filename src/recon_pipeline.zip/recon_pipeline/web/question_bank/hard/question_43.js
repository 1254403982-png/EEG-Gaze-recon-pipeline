window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:43, title:"傅里叶分析与信号频率", domain:"数学", difficulty:"高", diffClass:"is-high",
    summary:"傅里叶变换将时域信号分解为不同频率正弦波的叠加，卷积定理将时域卷积转换为频域乘积，是信号处理的基石。",
    quickQs:["傅里叶变换的直观理解","卷积定理的应用","给我出道练习题","用通俗语言解释"],
    content:`<p>同一段音乐，可以用"随时间变化的空气压强"（时域）来描述，也可以用"包含哪些频率成分"（频域）来描述。<strong>傅里叶分析</strong>就是在这两种视角之间自由转换的工具，是现代通信、音频、图像处理的基石。</p>
<h3>核心思想：任何信号都能拆成正弦波</h3>
<p>法国数学家傅里叶提出了一个惊人论断：<strong>任何周期信号（甚至非周期信号）都可以表示为一系列不同频率、不同幅度、不同相位的正弦波的叠加</strong>。这就像任何颜色都能由红绿蓝三原色调配出来，任何声音也能由不同频率的纯音调配出来。</p>
<div class="formula-block"><span class="formula-label">连续傅里叶变换</span>F(ω) = ∫ f(t)·e^(-iωt) dt<br>f(t) = (1/2π)∫ F(ω)·e^(iωt) dω<br>|F(ω)| = 频率ω分量的振幅，arg(F(ω)) = 相位</div>
<p>F(ω)叫做信号的<strong>频谱</strong>。比如对着钢琴录一个和弦，时域波形是一团乱麻，但频谱上会清晰地出现几个尖峰，对应被按下的几个琴键的频率。</p>
<h3>卷积定理：频域里的乘法</h3>
<p><strong>卷积</strong>是信号处理中最常见的运算（如平滑、模糊、滤波）。卷积在时域算起来很费劲，但傅里叶变换让它变得极其简单：</p>
<div class="formula-block"><span class="formula-label">卷积定理</span>时域卷积 f*g  ↔  频域相乘 F·G<br>时域相乘 f·g  ↔  频域卷积 F*G</div>
<p>这意味着：想给信号"滤波"（去掉某些频率），只需在频域把对应频率分量乘0（或乘小系数），再变回时域即可。这一招让MP3压缩、降噪耳机、医学CT成像成为可能。快速傅里叶变换(FFT)算法更把计算量从O(N²)降到O(N log N)，使实时信号处理成为现实。</p>`,
    quiz:[{ question:"傅里叶变换的核心功能是？", options:["A. 把时域信号转换到频域","B. 把频域转回时域","C. 放大信号","D. 直接降噪"], answerIndex:0 },
           { question:"根据卷积定理，时域中的卷积运算在频域中对应什么？", options:["A. 频域卷积","B. 频域乘积","C. 频域积分","D. 频域微分"], answerIndex:1 }] }
);
