window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:45, title:"高分子化学与材料性能", domain:"化学", difficulty:"高", diffClass:"is-high",
    summary:"高分子由重复单元通过聚合反应连接而成，聚合机理和链结构决定材料的力学性能，玻璃化转变是塑性与弹性的分界。",
    quickQs:["连锁聚合与逐步聚合的区别","玻璃化转变温度Tg","给我出道练习题","用通俗语言解释"],
    content:`<p>你身边几乎一切人造物品都和高分子有关：塑料袋、橡胶轮胎、涤纶衣服、医用缝合线……<strong>高分子（聚合物）</strong>是由成千上万个重复小单元（单体）串成的长链分子，分子量可达数十万甚至上百万。</p>
<h3>两类聚合机理</h3>
<table class="data-table">
<tr><th>类型</th><th>机理特征</th><th>单体要求</th><th>实例</th></tr>
<tr><td>连锁聚合</td><td>活性中心引发，快速链式增长</td><td>含双键（烯类）</td><td>聚乙烯、PVC、聚苯乙烯</td></tr>
<tr><td>逐步聚合</td><td>官能团间逐步缩合，分子量渐增</td><td>含两个及以上官能团</td><td>尼龙、聚酯、聚氨酯</td></tr>
</table>
<h3>链结构与性能</h3>
<p>高分子的"形状"决定用途：</p>
<ul style="padding-left:20px;">
<li><strong>线性高分子</strong>：链与链易滑动，可熔融、可溶解（热塑性塑料，如饮料瓶PET）。</li>
<li><strong>交联高分子</strong>：链间形成化学"桥"，不熔不溶（热固性，如 epoxy 胶、硫化橡胶）。</li>
<li><strong>支化/网状</strong>：影响结晶度和熔体粘度。</li>
</ul>
<h3>玻璃化转变温度 Tg</h3>
<p>这是高分子材料最重要的特征温度，相当于链段运动的"开关"：</p>
<div class="formula-block"><span class="formula-label">玻璃化转变</span>
T &lt; Tg：玻璃态，硬而脆（如常温下的塑料尺）<br>
T &gt; Tg：高弹态/橡胶态，柔软有弹性（如常温下的橡皮筋）<br>
结晶聚合物的熔点 Tm &gt; Tg</div>
<p>天然橡胶的Tg约-70°C，所以室温下是弹性的；聚苯乙烯的Tg约100°C，室温下是硬脆塑料。通过共聚、增塑等手段调节Tg，就能"定制"材料手感。</p>
<h3>链缠结与标度</h3>
<p>长链相互交叠形成物理缠结网络，带来高粘弹性和韧性。高分子物理用标度理论描述链尺寸与分子量关系：R ∝ N^ν（ν≈0.588为良溶剂）。这解释了为什么高分子熔体既像固体又像液体，行为复杂而迷人。</p>`,
    quiz:[{ question:"连锁聚合（如聚乙烯合成）的核心特征是？", options:["A. 分步慢速缩合反应","B. 活性中心引发、快速链式增长","C. 不产生高分子量","D. 产物纯度低"], answerIndex:1 },
           { question:"高分子的玻璃化转变温度Tg表示的是？", options:["A. 材料熔化的温度","B. 链段运动的开关：Tg以下玻璃态硬脆，以上高弹态","C. 分解温度","D. 沸点"], answerIndex:1 }] }
);
