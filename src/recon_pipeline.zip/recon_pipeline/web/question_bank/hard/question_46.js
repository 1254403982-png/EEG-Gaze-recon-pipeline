window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:46, title:"表观遗传学与基因调控", domain:"生物", difficulty:"高", diffClass:"is-high",
    summary:"表观遗传通过DNA甲基化、组蛋白修饰等方式调控基因表达，不改变DNA序列却可遗传，是环境影响遗传的关键机制。",
    quickQs:["DNA甲基化的作用","组蛋白修饰的组合","给我出道练习题","用通俗语言解释"],
    content:`<p>同卵双胞胎拥有完全相同的DNA，但随着年龄增长，他们外貌、健康、性格却出现差异。为什么基因相同却表现不同？答案藏在<strong>表观遗传学</strong>里——它研究在不改变DNA序列的前提下，如何开关基因。</p>
<h3>DNA甲基化：给基因"贴封条"</h3>
<p>在DNA的某些位点（尤其是CpG岛）添加甲基基团（-CH₃），通常会<strong>沉默基因</strong>。机制有三层：</p>
<div class="formula-block"><span class="formula-label">甲基化如何沉默基因</span>
① 直接挡住转录因子结合位点<br>
② 招募甲基结合蛋白(MBD) → 染色质浓缩<br>
③ 诱导组蛋白去乙酰化 → 进一步压紧染色质</div>
<p>细胞分裂时，DNA甲基转移酶(DNMT1)会以母链为模板，把甲基化模式"复制"到子链——这样表观遗传标记就能稳定遗传给后代细胞。</p>
<h3>组蛋白修饰：染色质的"开关旋钮"</h3>
<p>DNA不是裸奔的，而是缠绕在组蛋白八聚体上形成<strong>核小体</strong>。组蛋白尾巴上有多种化学修饰，像组合密码一样调控基因活性：</p>
<table class="data-table">
<tr><th>修饰</th><th>典型位点</th><th>效应</th></tr>
<tr><td>乙酰化</td><td>H3K9, H3K27</td><td>激活（染色质开放）</td></tr>
<tr><td>甲基化</td><td>H3K4(激活) / H3K27(沉默)</td><td>取决于具体位点</td></tr>
<tr><td>磷酸化</td><td>H3S10</td><td>染色体凝聚、转录激活</td></tr>
<tr><td>泛素化</td><td>H2B</td><td>激活或沉默</td></tr>
</table>
<h3>表观遗传的跨代传递与环境</h3>
<p>表观遗传标记可以跨越细胞分裂甚至代际传递。著名的<strong>荷兰冬季饥荒(1944-45)</strong>研究发现：孕期经历饥荒的母亲，其后代成年后代谢疾病风险显著升高，且这种效应与DNA甲基化模式的改变有关，可持续数代。此外，X染色体失活（雌性随机关掉一条X）、非编码RNA干扰等，都是表观遗传调控的重要形式。</p>`,
    quiz:[{ question:"表观遗传学的核心特征是什么？", options:["A. 改变DNA碱基序列","B. 不改变DNA序列但调控基因表达","C. 仅发生在生殖细胞","D. 完全不可逆"], answerIndex:1 },
           { question:"DNA甲基化通常对基因表达产生什么影响？", options:["A. 激活表达","B. 沉默表达","C. 无影响","D. 增强转录"], answerIndex:1 }] }
);
