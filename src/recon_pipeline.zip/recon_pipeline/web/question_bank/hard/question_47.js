window.questionBank = window.questionBank || {};
window.questionBank.hard = window.questionBank.hard || [];
window.questionBank.hard.push(
  { id:47, title:"TCP拥塞控制与流量调节", domain:"计算机", difficulty:"高", diffClass:"is-high",
    summary:"TCP通过拥塞窗口和接收窗口协同调节发送速率，慢启动、拥塞避免、快速重传与恢复构成完整拥塞控制策略。",
    quickQs:["拥塞控制四个阶段","TCP Reno与CUBIC的区别","给我出道练习题","用通俗语言解释"],
    content:`<p>互联网上数十亿设备同时通信，却没有中央调度。当某条链路被数据"堵爆"时，路由器队列溢出、丢包。TCP协议靠一套精巧的<strong>拥塞控制</strong>机制，让每台设备自觉地"该快则快、该慢则慢"，维持全网稳定。</p>
<h3>两个窗口的协作</h3>
<p>发送方能发多少数据，由<strong>两个窗口取最小值</strong>决定：</p>
<div class="formula-block"><span class="formula-label">发送窗口</span>发送窗口 = min( cwnd, rwnd )<br>cwnd = 拥塞窗口（网络承载能力，发送方自调）<br>rwnd = 接收窗口（接收方缓冲区剩余，防撑爆接收方）</div>
<h3>拥塞控制的四个阶段</h3>
<table class="data-table">
<tr><th>阶段</th><th>窗口变化</th><th>触发条件</th></tr>
<tr><td>慢启动</td><td>指数增长(每RTT翻倍)</td><td>连接刚建立，cwnd从1 MSS起</td></tr>
<tr><td>拥塞避免</td><td>线性增长(每RTT+1)</td><td>cwnd达到阈值ssthresh</td></tr>
<tr><td>快速重传</td><td>立即重传</td><td>收到3个重复ACK（不等超时）</td></tr>
<tr><td>快速恢复</td><td>cwnd减半，进拥塞避免</td><td>快速重传后(Reno算法)</td></tr>
</table>
<h3>算法演进与公平性</h3>
<p>经典Reno之后，CUBIC（三次函数增长，适合长肥管道）成为Linux默认；BBR（基于模型测带宽）用于高延迟网络。<strong>公平性</strong>方面，TCP的"加性增、乘性减(AIMD)"机制让多条流共享瓶颈时自然收敛到均分带宽——就像多个司机自觉轮流通过窄桥。</p>
<h3>丢包就是信号：ssthresh 的动态调整</h3>
<p>慢启动和拥塞避免之间靠一个阈值 <strong>ssthresh</strong> 衔接。一旦检测到丢包（超时或收到3个重复ACK），TCP就判断"网络拥堵了"：把 ssthresh 降为当前 cwnd 的一半，cwnd 也随之重置（超时则回到1、重新慢启动；Reno 则在快速恢复后令 cwnd = 新 ssthresh 的一半、进入拥塞避免）。这种"加性增、乘性减"让发送方在试探到可用带宽后会温和回退，既高效又不至于压垮网络。</p>`,
    quiz:[{ question:"TCP慢启动阶段拥塞窗口cwnd的变化特征是？", options:["A. 线性增长","B. 指数增长","C. 保持不变","D. 随机波动"], answerIndex:1 },
           { question:"TCP收到3个重复ACK后进入什么阶段？", options:["A. 慢启动","B. 拥塞避免","C. 快速重传","D. 超时重传"], answerIndex:2 }] }
);
